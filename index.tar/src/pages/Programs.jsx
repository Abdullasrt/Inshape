import React from 'react';
import { Link } from 'react-router-dom';
import { Clock, Flame, ChevronRight } from 'lucide-react';
import { motion } from 'framer-motion';

const smoothEasing = [0.16, 1, 0.3, 1];
const staggerContainer = {
  hidden: { opacity: 0 },
  visible: { opacity: 1, transition: { staggerChildren: 0.1, delayChildren: 0.05 } },
};
const fadeInUp = {
  hidden: { opacity: 0, y: 25 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.6, ease: smoothEasing } },
};

export default function Programs() {
  const programs = [
    { title: 'Hypertrophy & Power', category: 'Strength Building', intensity: 'High', duration: '60 Mins', description: 'Progressive overload protocols focused on muscle growth, compound lifts, and movement velocity.' },
    { title: 'Metabolic Conditioning', category: 'Endurance & Cardio', intensity: 'Extreme', duration: '45 Mins', description: 'High-intensity interval circuits to rapidly elevate VO2 max and stimulate metabolic burn.' },
    { title: 'Barbell Mechanics', category: 'Powerlifting', intensity: 'High', duration: '75 Mins', description: 'Deep technical coaching on squat, bench press, and deadlift leverage to maximize total weight output.' },
    { title: 'Mobility & Joint Health', category: 'Active Recovery', intensity: 'Low', duration: '50 Mins', description: 'Targeted joint capsule opening, myofascial release, and kinetic chain alignment for injury prevention.' },
  ];

  return (
    <motion.div initial="hidden" animate="visible" variants={staggerContainer} className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      {/* Header */}
      <motion.div variants={fadeInUp} className="text-center max-w-2xl mx-auto mb-16">
        <h1 className="text-4xl sm:text-5xl font-black text-white tracking-tight uppercase mb-4">TRAINING DISCIPLINES</h1>
        <p className="text-zinc-400">Scientifically designed programs to systematically reach target performance metrics.</p>
      </motion.div>

      {/* Grid */}
      <motion.div variants={staggerContainer} className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {programs.map((prog, idx) => (
          <motion.div
            key={idx}
            variants={fadeInUp}
            whileHover={{ y: -6, scale: 1.01 }}
            transition={{ type: 'spring', stiffness: 280, damping: 20 }}
            className="bg-zinc-900/50 border border-zinc-800 p-8 rounded-3xl hover:border-zinc-500 transition duration-300 relative group backdrop-blur-md"
          >
            <div className="flex justify-between items-center mb-6">
              <span className="text-xs font-bold text-zinc-200 bg-zinc-800 border border-zinc-700 px-3.5 py-1.5 rounded-full uppercase tracking-wider">
                {prog.category}
              </span>
              <div className="flex items-center gap-4 text-xs font-mono text-zinc-400">
                <span><Clock className="w-3.5 h-3.5 inline mr-1 text-zinc-400" />{prog.duration}</span>
                <span><Flame className="w-3.5 h-3.5 inline mr-1 text-white" />{prog.intensity}</span>
              </div>
            </div>

            <h3 className="text-2xl font-bold text-white mb-3">{prog.title}</h3>
            <p className="text-zinc-400 text-sm leading-relaxed mb-8">{prog.description}</p>

            <Link to="/contact" className="inline-flex items-center gap-2 text-xs font-bold uppercase tracking-widest text-white group-hover:text-zinc-300 transition duration-200">
              Reserve Slot <ChevronRight className="w-4 h-4 text-white group-hover:translate-x-1 transition duration-200" />
            </Link>
          </motion.div>
        ))}
      </motion.div>
    </motion.div>
  );
}