import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Zap, Award, Activity } from 'lucide-react';
import { motion } from 'framer-motion';

const smoothEasing = [0.16, 1, 0.3, 1];
const staggerContainer = {
  hidden: { opacity: 0 },
  visible: { opacity: 1, transition: { staggerChildren: 0.1, delayChildren: 0.05 } },
};
const fadeInUp = {
  hidden: { opacity: 0, y: 30 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.7, ease: smoothEasing } },
};

export default function Home() {
  const features = [
    { icon: <Zap className="w-6 h-6" />, title: "Prime Resistance Gear", desc: "Features custom resistance profiles designed to optimize muscular tension safely at peak contractions." },
    { icon: <Award className="w-6 h-6" />, title: "Biometric Diagnostics", desc: "Every membership includes complete body composition tracking and physiological movement screens." },
    { icon: <Activity className="w-6 h-6" />, title: "Infrared Recovery", desc: "Full access to cold plunges, Finnish saunas, and red-light therapy for optimal neurological recovery." },
  ];

  return (
    <motion.div initial="hidden" animate="visible" className="space-y-28 overflow-hidden">
      {/* HERO SECTION */}
      <motion.section variants={staggerContainer} className="relative pt-12 pb-16 md:pt-23 md:pb-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl">
            {/* Header Badge */}
            <motion.div variants={fadeInUp} className="flex items-center gap-4 mb-8">
              <motion.div whileHover={{ scale: 1.05, rotate: 4 }} transition={{ type: 'spring', stiffness: 300, damping: 15 }} className="w-16 h-16 sm:w-20 sm:h-20 bg-white rounded-full p-2 border border-zinc-700 shadow-2xl flex-shrink-0 flex items-center justify-center cursor-pointer">
                <img src="/logo.png.jpeg" alt="In Shape Mascot" className="w-full h-full object-contain" />
              </motion.div>
              <div>
                <span className="text-xs font-bold tracking-widest uppercase text-zinc-400 block">Welcome To</span>
                <span className="text-xl sm:text-2xl font-black tracking-wider text-white uppercase">IN SHAPE FITNESS UNLIMITED</span>
              </div>
            </motion.div>

            {/* Headline */}
            <motion.h1 variants={fadeInUp} className="text-6xl sm:text-7xl md:text-8xl font-black tracking-tighter text-white uppercase leading-[0.95] mb-8">
              PUNISH <br /><span className="text-zinc-400">AVERAGE.</span>
            </motion.h1>

            <motion.p variants={fadeInUp} className="text-zinc-400 text-lg sm:text-xl leading-relaxed mb-10 max-w-2xl font-light">
              Biromechanically calibrated machines, sport-specific strength programming, and personalized coaching built to dismantle plateaus.
            </motion.p>

            {/* CTA Buttons */}
            <motion.div variants={fadeInUp} className="flex flex-col sm:flex-row gap-4 mb-20">
              <motion.div whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}>
                <Link to="/pricing" className="group inline-flex items-center justify-center gap-3 bg-white hover:bg-zinc-200 text-black px-8 py-4 rounded-2xl font-black text-sm uppercase tracking-widest shadow-xl transition duration-300">
                  Claim Free Pass <ArrowRight className="w-5 h-5 text-black transition-transform duration-300 group-hover:translate-x-1" />
                </Link>
              </motion.div>
              <motion.div whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}>
                <Link to="/programs" className="inline-flex items-center justify-center bg-zinc-900 hover:bg-zinc-800 text-zinc-200 border border-zinc-800 px-8 py-4 rounded-2xl font-bold text-sm uppercase tracking-widest transition duration-300">
                  Explore Classes
                </Link>
              </motion.div>
            </motion.div>

          </div>
        </div>
      </motion.section>

      {/* BENTO GRID FEATURES */}
      <motion.section initial="hidden" whileInView="visible" viewport={{ once: true, margin: "-50px" }} variants={staggerContainer} className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div variants={fadeInUp} className="text-center max-w-2xl mx-auto mb-16">
          <h2 className="text-zinc-400 font-bold text-xs uppercase tracking-widest mb-3">Designed For Performance</h2>
          <p className="text-4xl font-black text-white tracking-tight">WHY ATHLETES CHOOSE INSHAPE</p>
        </motion.div>

        <motion.div variants={staggerContainer} className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {features.map((f, idx) => (
            <motion.div key={idx} variants={fadeInUp} whileHover={{ y: -8, transition: { duration: 0.3 } }} className="p-8 rounded-3xl bg-zinc-900/50 border border-zinc-800 hover:border-zinc-500 transition duration-300 group">
              <div className="p-3 bg-zinc-800 rounded-2xl text-white w-fit mb-6 group-hover:bg-white group-hover:text-black transition duration-300">{f.icon}</div>
              <h3 className="text-xl font-bold text-white mb-2">{f.title}</h3>
              <p className="text-zinc-400 text-sm leading-relaxed">{f.desc}</p>
            </motion.div>
          ))}
        </motion.div>
      </motion.section>
    </motion.div>
  );
}