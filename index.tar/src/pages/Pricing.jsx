import React, { useState } from 'react';
import { Check } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

const smoothEasing = [0.16, 1, 0.3, 1];
const staggerContainer = {
  hidden: { opacity: 0 },
  visible: { opacity: 1, transition: { staggerChildren: 0.1, delayChildren: 0.05 } },
};
const fadeInUp = {
  hidden: { opacity: 0, y: 25 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.6, ease: smoothEasing } },
};

export default function Pricing() {
  const [billingCycle, setBillingCycle] = useState('monthly');

  const plans = [
    {
      name: 'Standard Pass',
      price: billingCycle === 'monthly' ? '₹1000' : '₹1000',
      period: '/mo',
      description: 'Complete entry-level access for consistent individual training.',
      features: ['Access to main gym floor', 'Locker & sauna access', 'Biometric assessment', 'Mobile app tracking'],
      highlighted: false,
    },
    {
      name: 'Pro Athlete',
      price: billingCycle === 'monthly' ? '₹1500' : '₹1500',
      period: '/mo',
      description: 'Comprehensive membership designed for total performance.',
      features: ['24/7 Unlimited facility access', 'All group functional classes', 'Custom monthly programming', 'Sauna & Infrared recovery zone', '1 Monthly Personal Coaching session'],
      highlighted: true,
    },
    {
      name: 'Elite VIP',
      price: billingCycle === 'monthly' ? '₹2000' : '₹2000',
      period: '/mo',
      description: 'All-inclusive 1-on-1 personal coaching & recovery suite.',
      features: ['All Pro Athlete features', 'Unlimited Personal Training', 'Custom Macro & Nutrition plans', 'Free guest pass on every visit', 'Private VIP Lounge & Locker'],
      highlighted: false,
    },
  ];

  return (
    <motion.div initial="hidden" animate="visible" variants={staggerContainer} className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      {/* Header */}
      <motion.div variants={fadeInUp} className="text-center max-w-2xl mx-auto mb-16">
        <h1 className="text-4xl sm:text-5xl font-black text-white tracking-tight uppercase mb-4">MEMBERSHIP TIERS</h1>
        <p className="text-zinc-400">Straightforward pricing with no locked-in long-term commitments.</p>

        <div className="inline-flex items-center bg-zinc-900 border border-zinc-800 rounded-2xl p-1.5 mt-8">
          {['monthly', 'yearly'].map((cycle) => (
            <motion.button
              key={cycle}
              whileTap={{ scale: 0.95 }}
              onClick={() => setBillingCycle(cycle)}
              className={`px-6 py-2.5 rounded-xl text-xs font-bold uppercase tracking-wider transition duration-300 ${
                billingCycle === cycle ? 'bg-white text-black shadow-md' : 'text-zinc-400 hover:text-white'
              }`}
            >
              {cycle === 'monthly' ? 'Monthly' : 'Yearly (20% OFF)'}
            </motion.button>
          ))}
        </div>
      </motion.div>

      {/* Cards Grid */}
      <motion.div variants={staggerContainer} className="grid grid-cols-1 lg:grid-cols-3 gap-8 items-stretch">
        {plans.map((plan, idx) => (
          <motion.div
            key={idx}
            variants={fadeInUp}
            whileHover={{ y: -6, scale: 1.01 }}
            transition={{ type: 'spring', stiffness: 280, damping: 20 }}
            className={`relative flex flex-col justify-between rounded-3xl p-8 transition duration-300 backdrop-blur-md ${
              plan.highlighted ? 'bg-zinc-900 border-2 border-white shadow-2xl lg:-translate-y-2' : 'bg-zinc-950 border border-zinc-800'
            }`}
          >
            {plan.highlighted && (
              <motion.div initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} className="absolute -top-4 left-1/2 -translate-x-1/2 bg-white text-black text-[10px] font-black uppercase tracking-widest px-4 py-1.5 rounded-full shadow-md">
                Most Popular
              </motion.div>
            )}
            <div>
              <h3 className="text-2xl font-bold text-white">{plan.name}</h3>
              <p className="text-zinc-400 text-xs mt-2 min-h-[32px]">{plan.description}</p>

              <div className="my-6 flex items-baseline overflow-hidden">
                <AnimatePresence mode="wait">
                  <motion.span
                    key={plan.price}
                    initial={{ opacity: 0, y: -10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: 10 }}
                    transition={{ duration: 0.25, ease: 'easeOut' }}
                    className="text-5xl font-black text-white font-mono"
                  >
                    {plan.price}
                  </motion.span>
                </AnimatePresence>
                <span className="text-zinc-500 font-medium text-xs ml-1.5">{plan.period}</span>
              </div>

              <div className="h-px w-full bg-zinc-800 my-6" />

              <ul className="space-y-3.5">
                {plan.features.map((feature, fIdx) => (
                  <li key={fIdx} className="flex items-start gap-3 text-xs text-zinc-300">
                    <Check className="w-4 h-4 text-white flex-shrink-0 mt-0.5" />
                    <span>{feature}</span>
                  </li>
                ))}
              </ul>
            </div>

            <motion.button
              whileTap={{ scale: 0.98 }}
              className={`mt-10 w-full py-4 rounded-xl font-bold text-xs uppercase tracking-widest transition duration-300 ${
                plan.highlighted ? 'bg-white hover:bg-zinc-200 text-black shadow-md' : 'bg-zinc-800 hover:bg-zinc-700 text-white border border-zinc-700'
              }`}
            >
              Select Plan
            </motion.button>
          </motion.div>
        ))}
      </motion.div>
    </motion.div>
  );
}