import React from 'react';
import { Users } from 'lucide-react';
import { motion } from 'framer-motion';

const smoothEasing = [0.16, 1, 0.3, 1];
const staggerContainer = {
  hidden: { opacity: 0 },
  visible: { opacity: 1, transition: { staggerChildren: 0.1, delayChildren: 0.05 } },
};
const fadeInUp = {
  hidden: { opacity: 0, y: 25 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.6, ease: smoothEasing } },
};

export default function Trainers() {
  const trainers = [
    { name: 'Marcus Vance', role: 'Head Strength Coach', spec: 'Powerlifting & Biomechanics', experience: '12+ Years Experience' },
    { name: 'Elena Rostova', role: 'Functional Movement Specialist', spec: 'Mobility & Metabolic Conditioning', experience: '8+ Years Experience' },
    { name: 'David Miller', role: 'Bodybuilding & Nutrition Lead', spec: 'Contest Prep & Physiology', experience: '10+ Years Experience' },
  ];

  return (
    <motion.div initial="hidden" animate="visible" variants={staggerContainer} className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      {/* Header */}
      <motion.div variants={fadeInUp} className="text-center max-w-2xl mx-auto mb-16">
        <h1 className="text-4xl sm:text-5xl font-black text-white tracking-tight uppercase mb-4">ELITE COACHING STAFF</h1>
        <p className="text-zinc-400">Certified athletic coaches dedicated to guiding your target physical performance.</p>
      </motion.div>

      {/* Grid */}
      <motion.div variants={staggerContainer} className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {trainers.map((t, idx) => (
          <motion.div
            key={idx}
            variants={fadeInUp}
            whileHover={{ y: -6, scale: 1.01 }}
            transition={{ type: 'spring', stiffness: 280, damping: 20 }}
            className="bg-zinc-900/50 border border-zinc-800 p-8 rounded-3xl text-center group hover:border-zinc-500 transition duration-300 backdrop-blur-md"
          >
            {/* Avatar Badge */}
            <motion.div 
              whileHover={{ scale: 1.08, rotate: 3 }}
              transition={{ type: 'spring', stiffness: 300 }}
              className="w-24 h-24 bg-zinc-800 border-2 border-zinc-700 rounded-full mx-auto mb-6 flex items-center justify-center group-hover:bg-white group-hover:border-white transition duration-300"
            >
              <Users className="w-10 h-10 text-zinc-300 group-hover:text-black transition duration-300" />
            </motion.div>

            <h3 className="text-2xl font-bold text-white">{t.name}</h3>
            <p className="text-zinc-400 text-xs font-bold uppercase tracking-wider mt-1 mb-4">{t.role}</p>
            <p className="text-zinc-400 text-xs mb-2">
              <span className="text-zinc-200 font-semibold">Specialization:</span> {t.spec}
            </p>
            <p className="text-zinc-500 text-xs font-mono">{t.experience}</p>
          </motion.div>
        ))}
      </motion.div>
    </motion.div>
  );
}