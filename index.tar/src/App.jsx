import React from 'react';
import { Routes, Route } from 'react-router-dom';

// Layout Imports
import Navbar from './components/Navbar';
import Footer from './components/Footer';

// Page Imports
import Home from './pages/Home';
import About from './pages/About'; // <-- Added import
import Programs from './pages/Programs';
import Pricing from './pages/Pricing';
import Trainers from './pages/Trainers';
import Contact from './pages/Contact';

export default function App() {
  return (
    <div className="min-h-screen bg-black text-zinc-100 font-sans selection:bg-white selection:text-black flex flex-col justify-between relative overflow-hidden">
      {/* Monochrome Ambient Background Glow */}
      <div className="fixed top-[-10%] left-1/2 -translate-x-1/2 w-[1000px] h-[400px] bg-white/[0.03] blur-[160px] pointer-events-none rounded-full z-0" />

      {/* Persistent Navigation */}
      <Navbar />

      {/* Router Views */}
      <main className="flex-grow pt-24 z-10">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/about" element={<About />} /> {/* <-- Added route */}
          <Route path="/programs" element={<Programs />} />
          <Route path="/pricing" element={<Pricing />} />
          <Route path="/trainers" element={<Trainers />} />
          <Route path="/contact" element={<Contact />} />
        </Routes>
      </main>

      {/* Persistent Footer */}
      <Footer />
    </div>
  );
}