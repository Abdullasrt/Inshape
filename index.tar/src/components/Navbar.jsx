import React, { useState } from 'react';
import { Link, NavLink, useLocation } from 'react-router-dom';
import { Menu, X, Star } from 'lucide-react';

export default function Navbar() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const location = useLocation();

  const navLinks = [
    { name: 'Home', path: '/' },
    { name: 'About', path: '/about' },
    { name: 'Programs', path: '/programs' },
    { name: 'Membership', path: '/pricing' },
    { name: 'Trainers', path: '/trainers' },
    { name: 'Contact', path: '/contact' },
  ];

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-black/85 backdrop-blur-2xl border-b border-zinc-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          
          {/* LOGO BRANDING WITH CATCHY 2005 BADGE */}
          <Link to="/" className="flex items-center gap-3 group">
            <div className="w-12 h-12 bg-white rounded-full p-1 flex items-center justify-center border border-zinc-700 shadow-md transition duration-300 group-hover:scale-105">
              <img 
                src="/logo.png.jpeg" 
                alt="In Shape Fitness Unlimited Logo" 
                className="w-full h-full object-contain"
              />
            </div>
            <div className="flex flex-col">
              <span className="text-xl font-black tracking-widest text-white leading-none">
                IN <span className="text-zinc-400 font-light">SHAPE</span>
              </span>
              <div className="flex items-center gap-2 mt-1">
                <span className="text-[9px] font-bold tracking-widest uppercase text-zinc-400">
                  Fitness Unlimited
                </span>
                <span className="inline-flex items-center gap-1 text-[8px] font-black uppercase tracking-wider text-white bg-zinc-800 border border-zinc-700 px-2 py-0.5 rounded-full">
                  <Star className="w-2 h-2 fill-white text-white" /> SINCE 2005
                </span>
              </div>
            </div>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center gap-1 bg-zinc-900/80 p-1.5 rounded-2xl border border-zinc-800">
            {navLinks.map((link) => (
              <NavLink
                key={link.path}
                to={link.path}
                className={({ isActive }) =>
                  `px-5 py-2 rounded-xl text-xs font-bold tracking-wider uppercase transition-all duration-300 ${
                    isActive 
                      ? 'bg-white text-black shadow-md' 
                      : 'text-zinc-400 hover:text-white hover:bg-zinc-800/50'
                  }`
                }
              >
                {link.name}
              </NavLink>
            ))}
          </nav>

          <div className="hidden md:block">
            <Link
              to="/pricing"
              className="relative inline-flex items-center justify-center px-6 py-2.5 text-xs font-bold uppercase tracking-wider text-black bg-white rounded-xl shadow-md hover:bg-zinc-200 transition duration-300 active:scale-95"
            >
              Join Pass
            </Link>
          </div>

          {/* Mobile Navigation Toggle */}
          <div className="md:hidden">
            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="p-2.5 rounded-xl bg-zinc-900 border border-zinc-800 text-zinc-300 hover:text-white"
            >
              {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Dropdown */}
      {isMenuOpen && (
        <div className="md:hidden bg-zinc-950 border-b border-zinc-800 px-6 pt-4 pb-6 space-y-3 backdrop-blur-2xl">
          {navLinks.map((link) => (
            <Link
              key={link.path}
              to={link.path}
              onClick={() => setIsMenuOpen(false)}
              className={`block py-2 text-sm font-semibold uppercase tracking-wider ${
                location.pathname === link.path ? 'text-white font-bold' : 'text-zinc-400 hover:text-white'
              }`}
            >
              {link.name}
            </Link>
          ))}
          <Link
            to="/pricing"
            onClick={() => setIsMenuOpen(false)}
            className="block w-full text-center bg-white text-black py-3 rounded-xl font-bold uppercase text-xs tracking-widest mt-4"
          >
            Join Pass
          </Link>
        </div>
      )}
    </header>
  );
}