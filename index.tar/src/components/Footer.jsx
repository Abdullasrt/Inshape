import React from 'react';
import { Link } from 'react-router-dom';
import { Send } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-black/90 border-t border-zinc-900 py-16 text-zinc-400 text-sm mt-28 z-10 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid grid-cols-1 md:grid-cols-4 gap-10 mb-12">
        <div className="space-y-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-white rounded-full p-1 flex items-center justify-center border border-zinc-700">
              <img 
                src="/logo.png.jpeg" 
                alt="In Shape Fitness Unlimited Logo" 
                className="w-full h-full object-contain"
              />
            </div>
            <div className="flex flex-col">
              <span className="text-lg font-black text-white tracking-widest leading-none">
                IN <span className="text-zinc-400 font-light">SHAPE</span>
              </span>
              <span className="text-[8px] font-bold tracking-widest uppercase text-zinc-500 mt-0.5">
                Fitness Unlimited
              </span>
            </div>
          </div>
          <p className="text-zinc-500 text-xs leading-relaxed">
            Unleash your inner predator. High-performance strength equipment, personalized training, and unlimited potential.
          </p>
        </div>

        <div>
          <h4 className="text-white font-bold mb-4 text-xs tracking-widest uppercase">Navigation</h4>
          <ul className="space-y-2.5 text-xs">
            <li><Link to="/programs" className="hover:text-white transition">Programs & Schedules</Link></li>
            <li><Link to="/pricing" className="hover:text-white transition">Membership Tiers</Link></li>
            <li><Link to="/trainers" className="hover:text-white transition">Certified Coaches</Link></li>
            <li><Link to="/contact" className="hover:text-white transition">Facility Location</Link></li>
          </ul>
        </div>

        <div>
          <h4 className="text-white font-bold mb-4 text-xs tracking-widest uppercase">Operating Hours</h4>
          <ul className="space-y-2 text-xs text-zinc-500">
            <li className="flex justify-between"><span>Mon - Fri</span> <span className="text-white font-mono">05:00 - 23:00</span></li>
            <li className="flex justify-between"><span>Sat - Sun</span> <span className="text-white font-mono">06:00 - 22:00</span></li>
            <li className="text-white font-semibold pt-2">24/7 Access Available for VIP Tiers</li>
          </ul>
        </div>

        <div>
          <h4 className="text-white font-bold mb-4 text-xs tracking-widest uppercase">Insider Access</h4>
          <p className="text-xs text-zinc-500 mb-3">Get workout programming insights delivered weekly.</p>
          <div className="flex gap-2">
            <input
              type="email"
              placeholder="athlete@domain.com"
              className="bg-zinc-900 border border-zinc-800 rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-white flex-grow"
            />
            <button className="bg-white hover:bg-zinc-200 text-black px-4 py-2.5 rounded-xl text-xs font-bold transition">
              <Send className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 border-t border-zinc-900/80 pt-8 flex flex-col sm:flex-row justify-between items-center text-xs text-zinc-600 gap-4">
        <p>© {new Date().getFullYear()} In Shape Fitness Unlimited. All rights reserved.</p>
        <div className="flex gap-6 text-zinc-500">
          <a href="#" className="hover:text-white">Privacy Policy</a>
          <a href="#" className="hover:text-white">Terms of Service</a>
        </div>
      </div>
    </footer>
  );
}